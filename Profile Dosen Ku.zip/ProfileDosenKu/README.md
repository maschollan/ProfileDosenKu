# About

Aplikasi `Profile Dosen Ku` adalah aplikasi android sederhana yang dibuat untuk belajar mengenai `RecycleView` android dengan menggunkan study kasus list profile dosen serta untuk menyelesaikan tugas matkul PBB yang dibimbing oleh Dosen Pengampu :

> Pak Afandi Nur Aziz Thohari, S.T., M.Cs. [[github.com/afandi354](https://github.com/afandi354 "Menuju githubnya pak afandi")]

Diharapkan tugas ini dapat bermanfaat dengan baik dan dapat dikembangkan lebih baik lagi... :)

## Author
Kholan M ([github.com/maschollan](https://github.com/maschollan "Menuju githubnya saya")) student of Polytechnic Semarang State